# Attendance_Management_System
Android Application

# Description 
Attendance operations can be maintained through this ANDROID APP.

# About Application
SOFTWARE	:	ANDROID STUDIO<br />
BACK END	:	SQLITE<br/>

# Modules
1) Admin
2) Faculty 
3) Student

# Develop by..
Nanneboina Sumanth
